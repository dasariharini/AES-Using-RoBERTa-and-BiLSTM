import { useState } from "react";
import axios from "axios";
import "./EssayEvaluator.css";  // Import the updated CSS

const EssayEvaluator = () => {
    const [essay, setEssay] = useState("");
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleSubmit = async () => {
        if (!essay.trim()) {
            setError("Please enter an essay before submitting.");
            return;
        }
        setLoading(true);
        setError(null);

        try {
            const response = await axios.post("http://127.0.0.1:5000/evaluate", { essay });
            setResult(response.data);
        } catch (err) {
            setError("Failed to evaluate the essay. Please try again.");
        }

        setLoading(false);
    };

    return (
        <div className="essay-container">
            <h1 className="essay-heading">Essay Evaluator</h1>
            <textarea
                className="essay-textarea"
                placeholder="Enter your essay here..."
                value={essay}
                onChange={(e) => setEssay(e.target.value)}
            ></textarea>
            <button
                className="essay-button"
                onClick={handleSubmit}
                disabled={loading}
            >
                {loading ? "Evaluating..." : "Submit Essay"}
            </button>

            {error && <p className="result-text" style={{ color: "red" }}>{error}</p>}

            {result && (
                <div className="result-box">
                    <h2 className="result-title">Results</h2>
                    <p className="result-text"><strong>BiLSTM Score:</strong> {result.bilstm_score}</p>
                    <p className="result-text"><strong>Ollama Score:</strong> {result.ollama_score}</p>
                    <p className="result-text"><strong>Final Score:</strong> {result.final_score}</p>
                    <h3 className="result-title">Feedback:</h3>
                    <p className="feedback-text">{result.feedback.feedback}</p>
                </div>
            )}
        </div>
    );
};

export default EssayEvaluator;