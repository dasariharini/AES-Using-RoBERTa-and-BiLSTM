import pickle
import numpy as np
import json
import ollama
import tensorflow as tf
from flask import Flask, request, jsonify
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import load_model
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load BiLSTM Model and Tokenizer
print("Loading model artifacts...")
model = load_model('bilstm_essay_scorer.h5')
with open('tokenizer.pickle', 'rb') as handle:
    tokenizer = pickle.load(handle)
with open('config.pkl', 'rb') as f:
    config = pickle.load(f)

# Extract configuration
max_sequence_length = config['max_sequence_length']
score_mapping = config['score_mapping']
reverse_mapping = {v: k for k, v in score_mapping.items()}

# Function to preprocess text
def preprocess_text(text):
    text = str(text).lower().strip()
    text = ' '.join(text.split())
    text = text.replace('\n', ' ').replace('\r', ' ')
    return text

# Function to extract a score (1-5) from Ollama's response
def extract_score(feedback_json):
    try:
        # Ensure the response is a valid JSON
        feedback_data = json.loads(feedback_json)
        return float(feedback_data.get("score"))
    except (json.JSONDecodeError, TypeError, ValueError):
        return None  # Return None if parsing fails

# Function to predict score using BiLSTM model
def predict_bilstm_score(essay):
    """Predicts the essay score using BiLSTM model."""
    processed_essay = preprocess_text(essay)
    sequence = tokenizer.texts_to_sequences([processed_essay])
    padded_sequence = pad_sequences(sequence, maxlen=max_sequence_length)

    prediction = model.predict(padded_sequence)[0]

    if isinstance(prediction, np.ndarray) and len(prediction) > 1:
        predicted_class = np.argmax(prediction)
        return reverse_mapping.get(predicted_class, predicted_class)
    else:
        raw_score = float(prediction[0])
        rounded_score = int(round(raw_score))
        return reverse_mapping.get(rounded_score, rounded_score)

# Flask Route for Essay Evaluation
@app.route("/evaluate", methods=["POST"])
def evaluate_essay():
    try:
        data = request.json
        essay_text = data.get("essay", "")

        if not essay_text:
            return jsonify({"error": "No essay provided"}), 400

        # 1. Predict score using BiLSTM model
        bilstm_score = predict_bilstm_score(essay_text)

        # 2. Get feedback and score from Ollama
        ollama_prompt = """Evaluate the following essay and provide a JSON response with the following fields:
                        - score: A numeric score between 1 and 10.
                        - feedback: A detailed evaluation of the essay.

                        Respond ONLY with valid JSON.

                        Essay:
                        """ + essay_text

        ollama_response = ollama.chat(model="mistral", messages=[{"role": "user", "content": ollama_prompt}])
        ollama_feedback = ollama_response["message"]["content"]
        ollama_score = extract_score(ollama_feedback)

        # 3. Compute final averaged score
        if ollama_score is not None:
            final_score = round((bilstm_score + ollama_score) / 2, 1)
        else:
            final_score = bilstm_score  # Use BiLSTM score if Ollama fails

        return jsonify({
            "bilstm_score": bilstm_score * 2,  # Convert to 1-10 scale
            "ollama_score": ollama_score,
            "final_score": final_score,
            "feedback": json.loads(ollama_feedback) if ollama_score is not None else {"error": "Ollama response invalid"}
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)