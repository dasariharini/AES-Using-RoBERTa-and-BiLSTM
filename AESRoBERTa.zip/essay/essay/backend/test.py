import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle
import os

# Check if model files exist
required_files = ['bilstm_essay_scorer.h5', 'tokenizer.pickle', 'config.pkl']
missing_files = [f for f in required_files if not os.path.exists(f)]

if missing_files:
    print(f"Error: Missing required files: {', '.join(missing_files)}")
    print("Please ensure you've trained the model and generated these files first.")
    exit(1)

# Load model artifacts
print("Loading model artifacts...")
model = load_model('bilstm_essay_scorer.h5')
with open('tokenizer.pickle', 'rb') as handle:
    tokenizer = pickle.load(handle)
with open('config.pkl', 'rb') as f:
    config = pickle.load(f)

# Extract configuration
max_sequence_length = config['max_sequence_length']
score_mapping = config['score_mapping']

# Create reverse mapping
reverse_mapping = {v: k for k, v in score_mapping.items()}

# Define a sample essay that might score 3 marks
sample_essay = """
The Electoral College. The electoral college is ,to the office of federal register, "Is a process, not a place", which, in reality, it is. The electoral college is something that the founding fathers established for a choice of voting. You can either vote your election in congress or by a vote of the citizens. In my opinion, I don't really think that this is a good idea. No one really knows who's voting for who. And most of the time, voters don't always control who they get to vote for. But this can be a good thing sometimes because it helps keep everything in order.

First of all, the electoral college is a bad thing because nobody really knows who's voting for who. Most of the time, soem voters get confused about the whole thing and end up voting for the wrong person. During the election, most people get, as I said before, confused. These people get confused because there's too much going on. theres one side voting for one person, the other side voting for the other, then out of nowhere here comes like, 3 more people that are racing, and no one even knew whos these people were because everyone is too caught up with the states votes being all over the place to focus on anything else.

Secondly, I really think that the electoral college is not that good of an idea because most people that are voting don't even get a choice on who they want to vote for. The legislative branch is technically suppossed to choose the electors of the state. The electors are the people who allow peoples votes to go through. They pretty much just sit there and say if your vote counts. And sometimes it doesn't count. If it doesn't, they just give you to the other candidate. So you really don't have a choice to as to which candidate you vote for or not.

However, this could be a good thing.
"""

# Preprocess the sample essay (same preprocessing as in the original code)
def preprocess_text(text):
    text = str(text).lower()
    text = ' '.join(text.split())
    text = text.replace('\n', ' ').replace('\r', ' ')
    return text

# Prepare the essay for prediction
processed_essay = preprocess_text(sample_essay)
sequence = tokenizer.texts_to_sequences([processed_essay])
padded_sequence = pad_sequences(sequence, maxlen=max_sequence_length)

# Make prediction
print("\nMaking prediction for sample essay...")
prediction = model.predict(padded_sequence)[0]

# Interpret the prediction based on model type
if isinstance(prediction, np.ndarray) and len(prediction) > 1:
    # Multi-class classification
    predicted_class = np.argmax(prediction)
    predicted_score = reverse_mapping[predicted_class]
    confidence = prediction[predicted_class]
    print(f"Model type: Multi-class classification")
    print(f"Raw prediction: {prediction}")
    print(f"Predicted class: {predicted_class}")
    print(f"Confidence: {confidence:.2f}")
else:
    # Regression or binary classification
    raw_score = float(prediction[0])
    rounded_score = int(round(raw_score))
    
    # Map back to original score if needed
    if 0 in reverse_mapping:
        predicted_score = reverse_mapping[rounded_score]
    else:
        predicted_score = rounded_score
    
    print(f"Model type: Regression")
    print(f"Raw prediction: {raw_score:.2f}")

# Print final prediction
print(f"\nFinal predicted score: {predicted_score}")

# Print essay statistics
word_count = len(processed_essay.split())
print(f"\nEssay statistics:")
print(f"Word count: {word_count}")
print(f"Character count: {len(processed_essay)}")

# Print the first few words of the essay for verification
print(f"\nSample essay (first 100 characters):")
print(f"{processed_essay[:100]}...")

# Print interpretation of the score
score_interpretation = {
    1: "Poor - Significant improvement needed in organization, content, and language.",
    2: "Below Average - Needs improvement in multiple areas of writing.",
    3: "Average - Demonstrates basic competence but has room for improvement.",
    4: "Good - Well-written with minor areas for improvement.",
    5: "Excellent - Exceptional quality across all aspects of writing."
}

if predicted_score in score_interpretation:
    print(f"\nScore interpretation: {score_interpretation[predicted_score]}")
else:
    print(f"\nNote: The predicted score of {predicted_score} falls outside the standard 1-5 range.")
    print("The model might be using a different scoring scale.")