import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_squared_error, classification_report
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Bidirectional, LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt
import os
import time

# Set random seed for reproducibility
np.random.seed(42)

def load_data(csv_path, sample_size=None):
    print(f"Loading data from {csv_path}...")
    df = pd.read_csv(csv_path)
    print(f"Original dataset shape: {df.shape}")
    
    # Basic validation
    assert 'text' in df.columns, "CSV must contain a 'text' column"
    assert 'score' in df.columns, "CSV must contain a 'score' column"
    
    # Optional: Sample a subset of data for faster training
    if sample_size and sample_size < len(df):
        df = df.groupby('score', group_keys=False).apply(
            lambda x: x.sample(min(len(x), int(sample_size * len(x) / len(df))))
        )
        print(f"Sampled dataset shape: {df.shape}")
    
    # Check score distribution and print min and max scores
    print("Score distribution:")
    print(df['score'].value_counts().sort_index())
    print(f"Min score: {df['score'].min()}, Max score: {df['score'].max()}")
    
    # Split data
    train_df, val_df = train_test_split(
        df, test_size=0.2, random_state=42, stratify=df['score']
    )
    
    return train_df, val_df

def preprocess_text(text):
    # Basic preprocessing
    text = str(text).lower()
    # Remove excessive whitespace
    text = ' '.join(text.split())
    # Replace any characters that might cause issues
    text = text.replace('\n', ' ').replace('\r', ' ')
    return text

def prepare_text_data(train_df, val_df, max_words=20000, max_sequence_length=500):
    """
    Tokenize and prepare text data for BiLSTM model
    """
    # Preprocess text
    train_texts = [preprocess_text(text) for text in train_df['text']]
    val_texts = [preprocess_text(text) for text in val_df['text']]
    
    # Tokenize the text
    tokenizer = Tokenizer(num_words=max_words)
    tokenizer.fit_on_texts(train_texts)
    
    # Convert text to sequences
    train_sequences = tokenizer.texts_to_sequences(train_texts)
    val_sequences = tokenizer.texts_to_sequences(val_texts)
    
    # Pad sequences to ensure uniform length
    X_train = pad_sequences(train_sequences, maxlen=max_sequence_length)
    X_val = pad_sequences(val_sequences, maxlen=max_sequence_length)
    
    # Get all unique scores
    all_scores = np.union1d(train_df['score'].unique(), val_df['score'].unique())
    min_score = all_scores.min()
    
    # Adjust labels to start from 0 if needed
    if min_score > 0:
        print(f"Adjusting scores to be zero-indexed (subtracting {min_score})")
        y_train = train_df['score'].values - min_score
        y_val = val_df['score'].values - min_score
        score_mapping = {original: adjusted for original, adjusted in 
                         zip(range(min_score, min_score + len(all_scores)), range(len(all_scores)))}
        print(f"Score mapping: {score_mapping}")
    else:
        y_train = train_df['score'].values
        y_val = val_df['score'].values
        score_mapping = {score: score for score in all_scores}
    
    # Get the number of unique classes after adjustment
    num_classes = len(all_scores)
    print(f"Number of classes after adjustment: {num_classes}")
    print(f"Adjusted labels: {np.unique(y_train)}")
    
    return X_train, y_train, X_val, y_val, tokenizer, num_classes, score_mapping

def build_bilstm_model(vocab_size, embedding_dim=100, max_sequence_length=500, num_classes=1):
    """
    Build a BiLSTM model for essay scoring
    """
    model = Sequential()
    
    # Embedding layer
    model.add(Embedding(input_dim=vocab_size, 
                        output_dim=embedding_dim, 
                        input_length=max_sequence_length))
    
    # BiLSTM layers
    model.add(Bidirectional(LSTM(64, return_sequences=True)))
    model.add(Dropout(0.2))
    model.add(Bidirectional(LSTM(32)))
    model.add(Dropout(0.2))
    
    # Dense layers
    model.add(Dense(32, activation='relu'))
    model.add(Dropout(0.2))
    
    # Output layer
    if num_classes <= 2:  # For binary classification or regression
        model.add(Dense(1, activation='linear'))
        loss = 'mse'
        metrics = ['mae']
    else:  # For multi-class classification
        model.add(Dense(num_classes, activation='softmax'))
        loss = 'sparse_categorical_crossentropy'
        metrics = ['accuracy']
    
    # Compile the model
    model.compile(optimizer='adam', loss=loss, metrics=metrics)
    
    return model

def evaluate_model(model, X_val, y_val, num_classes, score_mapping):
    """
    Evaluate the BiLSTM model
    """
    # Make predictions
    if num_classes <= 2:  # Regression or binary classification
        y_pred_raw = model.predict(X_val).flatten()
        y_pred = np.round(y_pred_raw).astype(int)
    else:  # Multi-class classification
        y_pred_probs = model.predict(X_val)
        y_pred = np.argmax(y_pred_probs, axis=1)
    
    # Calculate metrics
    accuracy = accuracy_score(y_val, y_pred)
    rmse = np.sqrt(mean_squared_error(y_val, y_pred))
    
    print("\nDetailed Evaluation:")
    print(f"  Accuracy: {accuracy:.4f}")
    print(f"  RMSE: {rmse:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_val, y_pred))
    
    # Create a reverse mapping to convert back to original scores
    reverse_mapping = {v: k for k, v in score_mapping.items()}
    
    # Map some predictions back to original scores for display
    original_y_val = np.array([reverse_mapping[y] for y in y_val[:10]])
    original_y_pred = np.array([reverse_mapping[y] for y in y_pred[:10]])
    
    print("\nSample predictions (original score scale):")
    for i in range(min(10, len(y_val))):
        print(f"  True: {original_y_val[i]}, Predicted: {original_y_pred[i]}")
    
    return accuracy, rmse, y_pred

def plot_training_history(history):
    """
    Plot training & validation loss and metrics
    """
    plt.figure(figsize=(12, 5))
    
    # Plot training & validation loss
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('Model Loss')
    plt.ylabel('Loss')
    plt.xlabel('Epoch')
    plt.legend(['Train', 'Validation'], loc='upper right')
    
    # Plot training & validation accuracy if available
    if 'accuracy' in history.history:
        plt.subplot(1, 2, 2)
        plt.plot(history.history['accuracy'])
        plt.plot(history.history['val_accuracy'])
        plt.title('Model Accuracy')
        plt.ylabel('Accuracy')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Validation'], loc='lower right')
    elif 'mae' in history.history:
        plt.subplot(1, 2, 2)
        plt.plot(history.history['mae'])
        plt.plot(history.history['val_mae'])
        plt.title('Model MAE')
        plt.ylabel('MAE')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Validation'], loc='upper right')
    
    plt.tight_layout()
    plt.savefig('training_history.png')
    plt.close()

def save_model_artifacts(model, tokenizer, max_sequence_length, score_mapping):
    """
    Save the model and tokenizer
    """
    # Save the model
    model.save('bilstm_essay_scorer.h5')
    
    # Save the tokenizer
    import pickle
    with open('tokenizer.pickle', 'wb') as handle:
        pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
    # Save max_sequence_length and score_mapping
    with open('config.pkl', 'wb') as f:
        pickle.dump({
            'max_sequence_length': max_sequence_length,
            'score_mapping': score_mapping
        }, f)
    
    print("Model artifacts saved:")
    print("  - bilstm_essay_scorer.h5")
    print("  - tokenizer.pickle")
    print("  - config.pkl")

def main(csv_path, sample_size=None):
    # Load data
    train_df, val_df = load_data(csv_path, sample_size)
    
    # Set parameters
    max_words = 20000  # Maximum number of words in the vocabulary
    max_sequence_length = 500  # Maximum length of text sequences
    embedding_dim = 100  # Dimension of word embeddings
    
    # Prepare text data
    X_train, y_train, X_val, y_val, tokenizer, num_classes, score_mapping = prepare_text_data(
        train_df, val_df, max_words, max_sequence_length
    )
    
    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")
    
    # Build BiLSTM model
    model = build_bilstm_model(
        vocab_size=min(max_words, len(tokenizer.word_index) + 1),
        embedding_dim=embedding_dim,
        max_sequence_length=max_sequence_length,
        num_classes=num_classes
    )
    
    # Print model summary
    model.summary()
    
    # Define early stopping
    early_stopping = EarlyStopping(
        monitor='val_loss',
        patience=5,
        restore_best_weights=True
    )
    
    # Train the model
    print("\nTraining BiLSTM model...")
    start_time = time.time()
    
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=30,
        batch_size=32,
        callbacks=[early_stopping]
    )
    
    training_time = time.time() - start_time
    print(f"Training completed in {training_time:.2f} seconds")
    
    # Plot training history
    plot_training_history(history)
    
    # Evaluate the model
    accuracy, rmse, y_pred = evaluate_model(model, X_val, y_val, num_classes, score_mapping)
    
    # Save model artifacts
    save_model_artifacts(model, tokenizer, max_sequence_length, score_mapping)
    
    # Example prediction code
    print("\nExample usage for prediction:")
    print("from tensorflow.keras.models import load_model")
    print("from tensorflow.keras.preprocessing.sequence import pad_sequences")
    print("import pickle")
    print("import numpy as np")
    print("\n# Load model artifacts")
    print("model = load_model('bilstm_essay_scorer.h5')")
    print("with open('tokenizer.pickle', 'rb') as handle:")
    print("    tokenizer = pickle.load(handle)")
    print("with open('config.pkl', 'rb') as f:")
    print("    config = pickle.load(f)")
    print("\n# Prepare text for prediction")
    print("text = 'Your essay text here'")
    print("sequence = tokenizer.texts_to_sequences([text])")
    print("padded_sequence = pad_sequences(sequence, maxlen=config['max_sequence_length'])")
    print("\n# Make prediction")
    print("prediction = model.predict(padded_sequence)[0]")
    print("if isinstance(prediction, np.ndarray) and len(prediction) > 1:")
    print("    predicted_class = np.argmax(prediction)")
    print("    # Map back to original score")
    print("    score_mapping = config['score_mapping']")
    print("    reverse_mapping = {v: k for k, v in score_mapping.items()}")
    print("    predicted_score = reverse_mapping[predicted_class]")
    print("else:")
    print("    predicted_score = int(round(float(prediction)))")
    print("    # Map back to original score if needed")
    print("    if 'score_mapping' in config:")
    print("        reverse_mapping = {v: k for k, v in config['score_mapping'].items()}")
    print("        if 0 in reverse_mapping:")
    print("            predicted_score = reverse_mapping[predicted_score]")
    print("print(f'Predicted score: {predicted_score}')")

if __name__ == "__main__":
    csv_path = "/Users/krutin/Desktop/essay/balanced_essay_data.csv"
    sample_size = None  # Set to None to use all data or an integer to sample
    
    main(csv_path, sample_size)